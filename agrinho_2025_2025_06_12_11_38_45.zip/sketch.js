
let estado = "inicio";
let plantas = [];

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
}

function draw() {
  background(180, 230, 180);

  if (estado === "inicio") {
    textSize(24);
    text("Clica para plantar!", width / 2, height / 2);
  } else if (estado === "plantando") {
    for (let p of plantas) {
      p.mostrar();
      p.crescer();
    }
  }
}

function mousePressed() {
  if (estado === "inicio") {
    estado = "plantando";
  } else if (estado === "plantando") {
    plantas.push(new Planta(mouseX, mouseY));
  }
}

class Planta {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.altura = 10;
  }

  crescer() {
    if (this.altura < 100) {
      this.altura += 0.2;
    }
  }

  mostrar() {
    fill(34, 139, 34);
    rect(this.x, this.y - this.altura, 10, this.altura);
    fill(255, 204, 0);
    ellipse(this.x + 5, this.y - this.altura, 15, 15); // flor
  }
}
